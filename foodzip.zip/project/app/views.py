from django.shortcuts import render,HttpResponse,redirect
from .models import *
from django.conf import settings

# Create your views here.
def home(request):
    return render(request, 'home.html')
def blog(request):
    return render(request, 'blog.html')
def aboutus(request):
    return render(request,'aboutus.html')
def top5blog(request):
    return render(request,'top5blog.html')
def pastadishes(request):
    return render (request,'pastadishes.html')
def bbq(request):
    return render(request, 'bbq.html')
# def recipes(request):
#     return render(request,'recipes.html')

# def contact(request):
#     return render(request, 'contact.html')

def contact(request): 
    if request.method== 'POST':
        name= request.POST.get('name')
        email= request.POST.get('email')
        message= request.POST.get('message')
        print(name,email,message)
        user= Contact(name=name, email=email,  message=message)
        user.save()
    return render(request,"contact.html")

# def recipes(request):
#        return render(request, 'recipes.html')

def recipes(request):
    recipes = Recipe.objects.all()  # This should be using the singular 'Recipe'
    return render(request, 'recipes.html', {'recipes': recipes})