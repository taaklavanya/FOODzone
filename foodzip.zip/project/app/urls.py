from django.urls import path
from .views import*
from django.conf.urls.static import static

urlpatterns = [
    path('',home,name='home'),
    path('contact/',contact,name="contact"),
    path('blog/',blog,name='blog'),
    path('aboutus/',aboutus,name="aboutus"),
    path('top5blog/',top5blog,name="top5blog"),
    path('recipes/',recipes,name="recipes"),
    path('pastadishes/',pastadishes,name="pastadishes"),
    path('bbq/',bbq,name="bbq"),]


if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
